python runReplace.py
python runRegular.py
python plot.py
