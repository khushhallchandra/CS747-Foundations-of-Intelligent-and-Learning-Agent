python optimalPolicy.py $1
